import modelo_vetorial

modelo = modelo_vetorial.Modelo_vetorial()

indice_invertido = modelo.criar_indice_invertido()

peso = modelo.selecionar_peso_modelo()

matriz = modelo.montar_matriz(indice_invertido, peso)

modelo.loop_busca(matriz, indice_invertido, peso)
